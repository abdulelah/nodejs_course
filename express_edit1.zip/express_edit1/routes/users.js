'use strict';

// As you can see here we are going to include the following modules
var express = require('express');
var router = express.Router();
var async = require('async')
var _ = require('lodash')
var emailValidator = require('email-validator')
// We have build this utility to help us generate salted password
// that can be safely stored in the database
var passwordUtil = require('../helpers/hash_password')

/* GET registeration form. */
router.get('/', function(req, res, next) {
  res.render('user/login');
});


// receives login form
router.post('/', function(req, res, next) {
  // triming form fields is very important action to remove
  // any spaces at the bigaining or the end of the form fields
  var identity = _.trim(req.body.identity)
  var password = req.body.password

  async.waterfall (
    [

      // check if email or username is already registered
      function (callback) {
        req.knex
          .from ('user')
          .where (function () {
            this.where ('username', identity);
            this.orWhere ('email', identity);
          })
          .first ()
          .then (function (result) {
            if (!result || !result.user_id) 
                return callback(["provided identity and the password are not exist"]);
            
            return callback (null, result)

            
          })
          .catch (callback);
      },

      // Check if password is correct
      function (result, callback){
          // first we create a hashed password
          var hash_password = passwordUtil.sha512(password, result.salt)

          if(hash_password.passwordHash !== result.password){
            return callback(["password is incorrect"]);
          }

          return callback(null, result)
      },

      // create user token and the cookie
      function (result, callback){
        // to create token first we need to generate a random token number
        var randomTokenNumber = passwordUtil.genRandomString(32)

        // we will not build the most secure token number but in future
        // you should store the tokens in a better way
        var tokenHash = passwordUtil.sha512(randomTokenNumber, "")

        // then we store the token for the user in the database
        var data = {
            token: tokenHash.passwordHash,
            user_id: result.user_id,
            is_active: 1,
            created_at: new Date()
        }
        req.knex.insert(data)
              .into('user_token')
              .asCallback(function(err, insertId) {
                  callback(err, {token: randomTokenNumber, user_id: data.user_id});
              });

      },

      // last step is to set the cookie for the token
      function (result, callback){

        // first we chick if there are any exist user Cookie
        var cookie = req.cookies.userCookie;
        if (cookie === undefined)
        {
          res.cookie('userCookie',{token: result.token, user_id: result.user_id}, { maxAge: 900000, httpOnly: true });
          callback()
        } 
        else
        {
          callback(["cookie already exists"])
          // yes, cookie was already present 
          console.log('cookie exists', cookie);
        }
      }
    ],
    function (err, data) {
      // in the final call back we just check if there are any errors or
      // otherwise it means that the login was successful
      // so we will take the user to posts page
      if(err){
        return res.render('user/login', {
          identity: req.body.identity,
          errors: err
        });
      }
      res.redirect('/posts');
    }
  )

});

/* let user logout from the website */
router.get('/logout', function(req, res, next) {
  // check if cookie is exist and destroy it
  // also we should deactivate the session in the DB
  var cookie = req.cookies.userCookie;
  if (cookie){
    var tokenHash = passwordUtil.sha512(cookie.token, "") 
    req.knex('user_token')
      .update({'is_active': 0})
      .where('user_id', cookie.user_id)
      .where('token', tokenHash.passwordHash)
      .asCallback(function(err, insertId) {
        res.clearCookie("userCookie");
        return res.redirect('/');
      });
  }else{
    return res.redirect('/');
  }
})

/* GET registeration form. */
router.get('/register', function(req, res, next) {
  res.render('user/register');
});

/* recives registration form */
router.post('/register', function(req, res, next) {
  // triming form fields is very important action to remove
  // any spaces at the bigaining or the end of the form fields
  var username = _.trim(req.body.username)
  var email = _.trim(req.body.email)
  var password = req.body.password
  var confirm_password = req.body.confirm_password
    
  async.waterfall (
    [
      // check if the form fields are correct
      function(callback){
        // once we receive a request the first thing we should do is validations 
        var errors = []

        if(!_.isString(password) || password.length < 6)
            errors.push(req.i18n.__("Password length must be 6 or more digits"))
        
        if(!_.isString(username) || username.length < 2)
            errors.push(req.i18n.__("username length must be 2 or more digits"))

        if(!emailValidator.validate(email))
          errors.push(req.i18n.__("email is invalid"))

        if(password !== confirm_password)
          errors.push(req.i18n.__("passwords are not matching"))
          
        if(errors.length > 0)
          return callback(errors)
        return callback()
      },

      // check if email or username is already registered
      function (callback) {
        req.knex
          .from ('user')
          .where (function () {
            this.where ('username', username);
            this.orWhere ('email', email);
          })
          .first ()
          .then (function (result) {
            if (!result || !result.user_id) 
                return callback(null);
            
            return callback (["email or username are already exist"])

            
          })
          .catch (callback);
      },

      // create user
      function (callback){
          // first we create a hashed password
          var hash_password = passwordUtil.saltHashPassword(password)

          var data = {
              password: hash_password.passwordHash,
              salt: hash_password.salt,
              email,
              username,
              created_at: Date.now()
          }

          req.knex.insert(data)
              .into('user')
              .asCallback(function(err, insertId) {
                  callback(err, null);
              });
      }
    ],
    function (err, data) {
      if(err){
        return res.render('user/register', {
          username: req.body.username,
          email: req.body.email,
          password: req.body.password,
          errors: err
        });
      }
      res.render('user/completed_registration');
    }
  )

});

router.get('/password', function(req, res, next) {

  res.send('respond with a resource');
});

module.exports = router;
