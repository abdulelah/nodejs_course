var express = require('express');
var router = express.Router();

/* GET home page. */
router.get('/', function(req, res, next) {
  req.knex
    .from ('user')
    .first ()
    .then (function (result) {
      res.render('index', { title: result.username });
    })
    .catch (next);
});

/* GET home page. */
router.post('/post', function(req, res, next) {
  res.render('post', {
    name: req.body.name,
    title: 'Express'
  });
});

module.exports = router;
