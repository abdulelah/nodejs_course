'use strict';

// ceate a model action
module.exports.actionModel = (argA, argB) => {
  return new Promise ((resolve, reject) => {
    // Business logic

    if (errors) return reject (errors);
    resolve (data);
  });
};
