'use strict'

var async = require ('async')
var _ = require ('lodash')
var crypto            = require('crypto')
var emailValidator = require('email-validator')

var passwordUtil = require ('../helpers/hash_password');

// ceate token (login)
var createUser = (username, email, password) => {
    return new Promise ((resolve, reject) => {
      // First Step is to validate content
      var errors = []
      username = _.trim(username)
      email = _.trim(email)
      password = _.trim(password)
  
      if(!_.isString(password) || password.length < 6)
          errors.push("Password length must be 6 or more digits")
  
      
      if(!_.isString(username) || identifier.length < 2)
          errors.push("identifier length must be 2 or more digits")

      if(!emailValidator.validate(email))
        errors.push("email is invalid")
  
      if (errors)
        return reject(errors)
  
      
    })
  }

// ceate token (login)
var createToken = (identifier, password) => {
  return new Promise ((resolve, reject) => {
    // First Step is to validate content
    var errors = []
    identifier = _.trim(identifier);
    password = _.trim(password);

    if(!_.isString(password) || password.length < 6)
        errors.push("Password length must be 6 or more digits")

    
    if(!_.isString(identifier) || identifier.length < 2)
        errors.push("identifier length must be 2 or more digits")

    if (errors)
      return reject(errors)

    async.waterfall (
      [
        // get user data from database
        function (callback) {
          req.knex
            .from ('user')
            .where (function () {
              this.where ('username',identifier);
              this.orWhere ('email', identifier);
            })
            .first ()
            .then (function (result) {
              if (!result || !result.user_id) callback (404);

              callback (null, result);
            })
            .catch (callback);
        },

        // check if password is valid
        function (data, callback) {
            if (data.password !== password.sha512(password, data.password_salt))
                return callback (404);

            delete data.password
            delete data.password_salt
            callback (null, data);
        },

        // generate token
        function (data, callback){
            var token = data.user_id + '.' + crypto.createHash('md5').update(data.user_id + Date.now() + Math.random().toString(36).substring(5)).digest('hex');

            var data = {
                token: crypto.createHash('sha256').update(token).digest('base64'), // save token encrypted to database
                user_id: data.user_id,
                is_active: true,
                is_remeber_me: true,
                created_at: new Date()
            }

            req.knex.insert(data)
                .into('user_token')
                .asCallback(function(err, insertId) {
                    callback(err, token);
                });
        }
      ],
      function (err, data) {
        // Database error
        if (err) return reject (err);
        return resolve(data)
      }
    )
  })
}
