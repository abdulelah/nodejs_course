'use strict'



// We have build this utility to help us generate salted password
// that can be safely stored in the database
var passwordUtil = require('../helpers/hash_password')

module.exports = function(req, res, next) {

  req.isAuth = false
  var cookie = req.cookies.userCookie;
  if (cookie){
    var tokenHash = passwordUtil.sha512(cookie.token, "") 
    req.knex('user_token')
      .where({'is_active': 1})
      .where('user_id', cookie.user_id)
      .where('token', tokenHash.passwordHash)
      .first()
      .then(function(result, err) {
        if(err || !result)
          return next(err)
        req.isAuth = true
        return next()
      });
  }else{
    return next()
  }
}
