{
  "Registration Form": "نموذج التسجيل",
  "Your registration is successful": "تمت عملية التسجيل بنجاح",
  "Password length must be 6 or more digits": "Password length must be 6 or more digits",
  "email is invalid": "email is invalid",
  "identifier length must be 2 or more digits": "identifier length must be 2 or more digits",
  "passwords are not matching": "passwords are not matching",
  "Login Form": "Login Form",
  "Username or email": "Username or email"
}